<div align="center">

<img src="assets/hero.svg" alt="Abdourahamane DIALLO, développeur Full-Stack Web et Mobile, JeeriDev. Parcours : Guinée, Sénégal, Nouveau-Brunswick." width="100%" />

<img src="assets/stack.svg" alt="Stack : Java, Spring Boot, Spring Modulith, PostgreSQL, Flutter, GetX, React, TypeScript, Tailwind, NestJS, Docker, GitHub Actions, LaTeX" width="100%" />

**[LinkedIn](https://www.linkedin.com/in/abdourahamane-diallo-3075b428a)** · Ouvert aux opportunités de développeur Full-Stack junior · Nouveau-Brunswick, Canada

</div>

## À propos

Originaire de Guinée, formé au Sénégal, installé au Nouveau-Brunswick. Je conçois des backends **Spring Boot** en architecture hexagonale, des applications mobiles **Flutter** et des interfaces **React + TypeScript**. Je travaille sous la marque **JeeriDev** et je vise le métier d'**architecte logiciel**.

- **Formation** : École du Code Sonatel Academy × Orange Digital Center (Dakar, promotion 7, 2024–2025). Premières lignes de code à l'Université Assane Seck de Ziguinchor.
- **Études** : Techniques multidisciplinaires en systèmes informatiques, CCNB, depuis septembre 2026.
- **J'approfondis** : NestJS (microservices), TDD, patterns d'architecture et d'intégration. Je documente en LaTeX / Beamer.
- **Hors code** : l'architecture du bâtiment. J'explore des concepts de villas modernes adaptées au climat ouest-africain.

## Architecture de référence

<img src="assets/hexagonal.svg" alt="Schéma d'architecture hexagonale : API REST, application mobile et web à gauche, domaine au centre, base de données et événements à droite" width="100%" />

C'est le schéma que j'applique sur mes backends : SOLID et DDD dans le domaine, Spring Modulith pour les frontières de modules, multi-tenance PostgreSQL par `tenant_id`, GetX Clean Architecture côté Flutter, Git Flow et CI/CD avec GitHub Actions, SonarCloud et Dokploy.

## Projets

| Projet | Ce que c'est | Stack |
|---|---|---|
| **Mobile Money : plateforme de grossistes et app terrain** | Projet de fin de formation, soutenu : plateforme multi-tenant de gestion de grossistes Mobile Money (paiements récurrents planifiés, import massif Excel/CSV, quotas par tenant). **uv_distrib** : application de gestion d'agents de terrain pour les opérations Mobile Money. | Java · Spring Boot · Spring Modulith · PostgreSQL · Flyway · Flutter · GetX |
| **[Sentinelle](https://sentinelle.tinkin.tech/)** | Signalement anonyme du racisme et des discriminations au Nouveau-Brunswick : parcours en 3 étapes pensé mobile d'abord, tableaux de bord pour le personnel. Frontend en ligne, backend NestJS à venir. | React · TypeScript · Vite · Tailwind · shadcn/ui · react-i18next · Vitest |
| **MarketFlow** | Interface SaaS de gestion de supermarché, avec une page de connexion animée en canvas (particules et constellations). Backend NestJS prévu. | React · TypeScript · Vite · Tailwind · shadcn/ui |
| **Gestion de poulailler** | Application mobile de gestion de ferme avicole : modules par rôle (Fermier, Distributeur, Propriétaire), factures PDF, scan de codes QR. | Flutter · GetX |

## Activité

<div align="center">
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/snake-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="assets/snake.svg" />
  <img alt="Serpent animé qui mange mes contributions GitHub" src="assets/snake.svg" width="100%" />
</picture>
</div>

<details>
<summary>English summary</summary>

**Full-stack web & mobile developer** from Guinea, trained in Senegal, now studying and living in New Brunswick, Canada. I build backends with **Spring Boot** (hexagonal architecture, DDD, modular monolith), mobile apps with **Flutter**, and web apps with **React + TypeScript**. Goal: become a **software architect**. Open to junior full-stack opportunities. My English is a work in progress, and I'm actively improving it.

</details>
